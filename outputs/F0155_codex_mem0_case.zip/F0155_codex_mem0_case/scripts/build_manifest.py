# -*- coding: utf-8 -*-
"""Regenerate manifest.json for the public package.

Usage (from the package root):  python scripts/build_manifest.py
"""
import hashlib, json, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PURPOSES = {
    "README.md": "Case narrative, scope of evidence, sanitization notes and reproduction entry points.",
    "manifest.json": "File inventory with roles and SHA-256 digests.",
    "case/case.json": "Question, decision objective, reference and attacker policies, all six experience texts.",
    "case/orders.json": "The two submission orders, the moved attacker block, and the event-multiset check.",
    "case/downstream_task.txt": "The exact downstream prompt shared by all three groups.",
    "case/scoring.json": "Action mapping, verdict rules and the pair-success criterion.",
    "case/initial_repo.json": "Initial file state of the isolated repository.",
    "case/upstream_protocol.json": "Archive-transcription submission protocol, its wrapper and instruction, and the submitted-prompt digest for each event.",
    "CASE_DESCRIPTION_EN.md": "Short English case description for external readers.",
}

def sha_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(65536), b""):
            h.update(c)
    return h.hexdigest()

def purpose_of(rel):
    if rel in PURPOSES:
        return PURPOSES[rel]
    if rel.startswith("evidence/"):
        parts = rel.split("/")
        g = parts[1] if len(parts) > 1 else ""
        rest = "/".join(parts[2:])
        label = {"clean": "Clean history", "poison": "Poisoned history",
                 "baseline": "No-memory baseline"}.get(g, g)
        if rest.startswith("logs/"):
            return "Sanitized session log for the %s." % label
        if rest.startswith("repo/"):
            return "Final repository file %s for the %s." % (rest[5:], label)
        if rest == "upstream_events.json":
            return "Per-event submission, flush and extraction record for the %s." % label
        if rest == "memories.json":
            return "Persisted memories and the session that wrote each one, for the %s." % label
        if rest == "retrieval.json":
            return "Plugin retrieval rows (rank, score, memory) for the %s." % label
        if rest == "injection.json":
            return "Automatic injection record for the %s." % label
        if rest == "injection.txt":
            return "Exact injected developer context for the %s." % label
        if rest == "downstream.json":
            return "Downstream session result: tool calls, reasoning and final file state, for the %s." % label
        if rest == "downstream_prompt.txt":
            return "Downstream prompt as delivered in the %s session." % label
        if g == "database":
            return "Row-level plugin database export for the %s scope." % label
    if rel.startswith("scripts/"):
        return "Verification or manifest-generation helper."
    return "Package file."

files = []
for root, dirs, fs in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d != "__pycache__"]
    for f in sorted(fs):
        p = os.path.join(root, f)
        rel = os.path.relpath(p, ROOT).replace(os.sep, "/")
        if rel == "manifest.json":
            continue
        files.append({"path": rel, "purpose": purpose_of(rel),
                      "bytes": os.path.getsize(p), "sha256": sha_file(p)})

man = {
    "package": "F0155_codex_mem0_case",
    "title": "Codex + Mem0 path-poisoning end-to-end case: F0155 customer support access restoration",
    "hash_algorithm": "sha256",
    "hash_scope": "Hashes cover the sanitized public copies in this package, not the private originals. They verify the integrity of the distributed copy only and cannot show that a sanitized file is byte-identical to its private source.",
    "sanitization": {
        "structured": [
            "account and user identifiers removed",
            "absolute host paths and workspace names replaced with placeholders",
            "session and memory identifiers replaced by deterministic aliases",
            "base-instruction and host environment snapshot text replaced by SHA-256 digests",
        ],
        "aliases": "Session and memory aliases are deterministic within this package and stable across files.",
    },
    "file_count": len(files),
    "files": files,
}
open(os.path.join(ROOT, "manifest.json"), "w", encoding="utf-8", newline="\n").write(
    json.dumps(man, ensure_ascii=False, indent=2) + "\n")
print("manifest written with %d files" % len(files))
